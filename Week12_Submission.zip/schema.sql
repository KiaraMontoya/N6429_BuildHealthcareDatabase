PRAGMA foreign_keys = ON;

CREATE TABLE clinics (
    clinic_id TEXT PRIMARY KEY,
    clinic_name TEXT NOT NULL UNIQUE,
    region TEXT NOT NULL
);

CREATE TABLE patients (
    patient_id TEXT PRIMARY KEY,
    birth_year INTEGER NOT NULL,
    preferred_language TEXT NOT NULL,
    social_needs_flag INTEGER NOT NULL CHECK (social_needs_flag IN (0, 1))
);

-- CREATE encounters using these CSV fields:
-- encounter_id, patient_id, clinic_id, encounter_date, visit_type
-- Add foreign keys to patients and clinics.
CREATE TABLE encounters (
  encounter_id TEXT PRIMARY KEY,
  patient_id TEXT NOT NULL,
  clinic_id TEXT NOT NULL,
  encounter_date TEXT NOT NULL,
  visit_type TEXT NOT NULL,
  FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
  FOREIGN KEY (clinic_id) REFERENCES clinics(clinic_id)
);

-- CREATE referrals using these CSV fields:
-- referral_id, encounter_id, service_type, referral_date, priority, due_date
-- Add a foreign key to encounters and a CHECK for priority.
CREATE TABLE referrals (
  referral_id TEXT PRIMARY KEY,
  encounter_id TEXT NOT NULL,
  service_type TEXT NOT NULL,
  referral_date TEXT NOT NULL,
  priority TEXT NOT NULL CHECK (priority IN ('Routine', 'High')),
  due_date TEXT NOT NULL,
  FOREIGN KEY (encounter_id) REFERENCES encounters(encounter_id)
);

-- CREATE followups using these CSV fields:
-- followup_id, referral_id, completion_date, outcome, contact_attempts
-- Make referral_id UNIQUE, add the foreign key to referrals, and add
-- appropriate CHECK constraints for outcome and contact_attempts.
CREATE TABLE followups (
  followup_id TEXT PRIMARY KEY,
  referral_id TEXT NOT NULL UNIQUE,
  completion_date TEXT,
  outcome TEXT NOT NULL,
  contact_attempts INTEGER NOT NULL CHECK (contact_attempts >= 0),
  FOREIGN KEY (referral_id) REFERENCES referrals(referral_id)
);
